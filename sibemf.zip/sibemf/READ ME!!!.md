Berikut ini penjelasan CodeIgniter ini:
<ol>
	<li>Model, controller, dan view tinggal dipake aja</li>
	<li>Settingan database bisa diubah (tapi kayaknya gak usah diubah)</li>
	<li>Web belum dicoba (debug), malam ini aku debug webnya</li>
	<li>File css, js, dll. dimasukkan ke folder assets, nanti di elemen src tinggal ditambah <br>
		<&nbsp><&nbsp>	&lt;?php echo assets_url() ?&gt;, itu untuk menunjukkan url lokasi folder assets</li>
	<li>Sudah ada .htaccess, jadi untuk buka web gak perlu pake index.php, langsung aja: localhost/sibemf/welcome...</li>
	<li>Segala pertanyaan langsung hubungi saya, huehuehue</li>
</ol>
