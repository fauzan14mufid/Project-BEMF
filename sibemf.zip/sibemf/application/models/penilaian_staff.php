<?php
/**
 * Created by PhpStorm.
 * User: andre.na70
 * Date: 3/2/2015
 * Time: 6:09 PM
 */

class Penilaian_Staff extends CI_Model {
    public function setNilaiStaff()
    {
        // tinggal pake
    }

    public function getNilaiStaff()
    {
        // bentar
    }
}

?>