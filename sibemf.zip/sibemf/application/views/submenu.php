<!DOCTYPE html>
<html>
<head>
    

<!--	<script src="JS.js"> </script>-->
	<link href="<?php echo asset_url(); ?>/submenu/style.css" rel="stylesheet" type="text/css">

    <title>Menu BPH</title>
</head>
<body>
    <h1 class="judul">Menu Badan Pengurus harian Departemen [SRD]</h1>
    
	<ul>
  <li><a href="#" class="round green">ABSEN<span class="round">Memasukkan Absensi Staff BEM FTIf.</span></a></li>
  <li><a href="#" class="round red">Penilaian<span class="round">Memasukkan Penilaian Perbulan Staff BEM FTIf. </span></a></li>
</ul> 
</body>
</html>
